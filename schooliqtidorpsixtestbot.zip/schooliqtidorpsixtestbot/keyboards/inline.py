from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def start_inline_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Testni boshlash 🚀", callback_data="start_test")]
    ])

def start_test_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Testni boshlash 🚀", callback_data="begin_test")]
    ])

def question_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="1", callback_data="answer:1"),
         InlineKeyboardButton(text="2", callback_data="answer:2")]
    ])

# Create your keyboards here.
# Inline keyboard yaratish funksiyasi (obuna uchun)

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
import logging


from handlers.Channels import CHANNELS


def keyboard() -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=channel["name"], url=channel["link"])]
        for channel in CHANNELS
    ]
    buttons.append([InlineKeyboardButton(text="🔍 Tekshirish", callback_data="check_subscription")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
    return keyboard