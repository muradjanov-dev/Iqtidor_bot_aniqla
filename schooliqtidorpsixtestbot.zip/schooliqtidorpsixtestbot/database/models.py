from sqlalchemy import Column, Integer, String, BigInteger, ForeignKey
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, nullable=False)
    unique_id = Column(String, unique=True, nullable=False)
    first_name = Column(String)
    last_name = Column(String)
    phone_number = Column(String)
    age = Column(Integer)
    status = Column(String, default='new')

class Answer(Base):
    __tablename__ = 'answers'
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, nullable=False)
    unique_id = Column(String, nullable=False)
    question_number = Column(Integer, nullable=False)
    answer = Column(Integer, nullable=False)  # 1 yoki 2