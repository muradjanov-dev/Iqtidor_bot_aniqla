from sqlalchemy import func
from database.db import SessionLocal
from database.models import User

def generate_unique_id():
    with SessionLocal() as session:
        max_id = session.query(func.max(User.id)).scalar() or 0
        return f"{max_id + 1:05d}"  # 00001, 00002 va h.k.