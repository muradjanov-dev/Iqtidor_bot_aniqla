import openpyxl
import os
import re
import logging
from aiogram.types import FSInputFile
from config import GROUP_ID
from database.db import SessionLocal
from database.models import User, Answer
from utils.questions_loader import load_questions

# Logging sozlash
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def create_excel(unique_id: str, bot):
    try:
        # Ma'lumotlar bazasidan foydalanuvchi va javoblar olish
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            if not user:
                logger.error(f"User with unique_id {unique_id} not found")
                return
            answers = session.query(Answer).filter(Answer.unique_id == unique_id).order_by(Answer.question_number).all()

        # Savollarni yuklash
        questions = load_questions()
        if not questions or len(questions) < 30:
            logger.warning("Questions not loaded properly, using default")
            questions = [{"question": f"Savol {i}", "options": ["N/A", "N/A"]} for i in range(1, 31)]

        # Excel fayl yaratish
        wb = openpyxl.Workbook()
        ws = wb.active
        headers = ['Unique ID', 'Ism', 'Familiya', 'Telefon', 'Yosh'] + [q['question'] for q in questions]
        ws.append(headers)

        # Ma'lumotlarni to'ldirish
        row = [
            user.unique_id,
            user.first_name or 'Nomalum',
            user.last_name or 'Nomalum',
            user.phone_number or 'Nomalum',
            user.age or 'Nomalum'
        ]
        answer_dict = {a.question_number: questions[a.question_number-1]['options'][a.answer-1] for a in answers}
        for i in range(1, 31):
            row.append(answer_dict.get(i, 'Javob berilmagan'))

        ws.append(row)

        # Fayl nomini tozalash
        clean_name = f"{user.first_name or 'Nomalum'}_{user.last_name or 'Nomalum'}"
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '', clean_name).replace(' ', '_')
        if not clean_name or clean_name == '_':
            clean_name = 'Foydalanuvchi'
        filename = f"{user.unique_id}_{clean_name}.xlsx"

        # Faylni saqlash
        wb.save(filename)
        logger.info(f"Excel file created: {filename}")

        # Guruhga yuborish
        try:
            await bot.send_document(
                chat_id=GROUP_ID,
                document=FSInputFile(filename),
                caption=f"Foydalanuvchi {user.unique_id} test natijasi"
            )
            logger.info(f"Excel file sent to group: {filename}")
        except Exception as e:
            logger.error(f"Error sending Excel file to group: {e}")
            return

        # Faylni o'chirish
        try:
            os.remove(filename)
            logger.info(f"Excel file deleted: {filename}")
        except Exception as e:
            logger.error(f"Error deleting Excel file: {e}")

    except Exception as e:
        logger.error(f"Error in create_excel for unique_id {unique_id}: {e}")