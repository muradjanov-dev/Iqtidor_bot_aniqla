import json
import os

def load_questions():
    if os.path.exists('questions.json'):
        with open('questions.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        # Standart savollar (30 ta)
        return [{"question": f"Savol {i} topilmadi", "options": ["N/A", "N/A"]} for i in range(1, 31)]