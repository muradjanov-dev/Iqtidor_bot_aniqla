def validate_phone(phone: str) -> bool:
    return phone.startswith('+') and len(phone[1:]) >= 10 and phone[1:].isdigit()

def validate_age(age: str) -> bool:
    try:
        age_int = int(age)
        return 2 <= age_int <= 100
    except ValueError:
        return False