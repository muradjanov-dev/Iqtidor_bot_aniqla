from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from database.db import SessionLocal
from database.models import User, Answer
from states.test import TestStates
from keyboards.inline import question_keyboard
from utils.questions_loader import load_questions
from utils.excel import create_excel
from config import BOT_TOKEN, CHANNEL_IDS
from aiogram import Bot
import logging

test_router = Router()
bot = Bot(token=BOT_TOKEN)

# Logging sozlash
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_subscription(user_id: int) -> bool:
    """Foydalanuvchining barcha kanallarga obuna ekanligini tekshiradi."""
    try:
        for channel_id in CHANNEL_IDS:
            chat_member = await bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            if chat_member.status not in ["member", "administrator", "creator"]:
                return False
        return True
    except Exception as e:
        logger.error(f"Error checking subscription for user {user_id}: {e}")
        return False

def get_subscription_keyboard():
    """Kanallar uchun inline tugmalar yaratadi."""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    keyboard = []
    for channel_id in CHANNEL_IDS:
        channel_name = channel_id.replace("@", "")
        keyboard.append([InlineKeyboardButton(
            text=f"{channel_id} | Obuna",
            url=f"https://t.me/{channel_name}"
        )])
    keyboard.append([InlineKeyboardButton(text="Tekshirish ✅", callback_data="check_subscription")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

@test_router.callback_query(F.data.startswith("answer:"), TestStates.answering)
async def process_answer(callback: CallbackQuery, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(callback.from_user.id):
        await callback.message.edit_text(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        await callback.answer()
        return

    answer = int(callback.data.split(":")[1])
    data = await state.get_data()
    unique_id = data['unique_id']
    current_question = data['current_question']

    try:
        with SessionLocal() as session:
            new_answer = Answer(telegram_id=callback.from_user.id, unique_id=unique_id, question_number=current_question, answer=answer)
            session.add(new_answer)
            session.commit()
            logger.info(f"Answer {answer} saved for question {current_question}, unique_id {unique_id}")
    except Exception as e:
        logger.error(f"Error saving answer: {e}")
        await callback.message.answer("😔 Xato yuz berdi. /start bilan qayta urining.")
        await callback.answer()
        await state.clear()
        return

    if current_question < 30:
        next_question = current_question + 1
        await state.update_data(current_question=next_question)
        questions = load_questions()
        q = questions[next_question - 1]
        try:
            await callback.message.edit_text(
                f"🌟 Savol {next_question}/30: \n\n{q['question']}\n\n1: {q['options'][0]}\n2: {q['options'][1]}\n\nTanlang 😊",
                reply_markup=question_keyboard()
            )
        except Exception as e:
            logger.warning(f"Edit failed: {e}. Sending new message instead.")
            await callback.message.answer(
                f"🌟 Savol {next_question}/30: \n\n{q['question']}\n\n1: {q['options'][0]}\n2: {q['options'][1]}\n\nTanlang 😊",
                reply_markup=question_keyboard()
            )
    else:
        try:
            with SessionLocal() as session:
                user = session.query(User).filter(User.unique_id == unique_id).first()
                user.status = 'test_completed'
                session.commit()
                logger.info(f"Test completed for unique_id {unique_id}")

            await callback.message.edit_text("""🎉 Testni muvaffaqiyatli yakunladingiz! Javoblari kitob holatida batafsil sharxlari bilan boʻladi. Siz javoblar kitobini IQtidor maktabimizga kelib olib ketishingiz mumkin.\n\nMaktabimizga kelsangiz kelajak kasbingiz va iqtidoringiz aniqlangan kitobga qoʻshimcha sovgʻalarni qoʻlga kiritasiz. Sizni maktabimizda kutamiz!\n\n📍 Manzilimiz: Kitob tumani markazish kasalxonasidan oʻtganda, "Versal" tantanalar saroyi chorraxasida.\n\n☎️ Telefon: +998990923006\n@iqtidormaktabi""")
            await create_excel(unique_id, bot)
        except Exception as e:
            logger.error(f"Error completing test: {e}")
            await callback.message.answer("😔 Testni yakunlashda xato yuz berdi. /start bilan qayta urining.")
        finally:
            await state.clear()

    await callback.answer()

@test_router.callback_query(F.data == "check_subscription", TestStates.answering)
async def check_subscription_in_test(callback: CallbackQuery, state: FSMContext):
    if await check_subscription(callback.from_user.id):
        data = await state.get_data()
        current_question = data.get('current_question', 1)
        questions = load_questions()
        q = questions[current_question - 1]
        await callback.message.edit_text(
            f"🌟 Savol {current_question}/30: \n\n{q['question']}\n\n1: {q['options'][0]}\n2: {q['options'][1]}\n\nTanlang 😊",
            reply_markup=question_keyboard()
        )
    else:
        await callback.message.edit_text(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
    await callback.answer()