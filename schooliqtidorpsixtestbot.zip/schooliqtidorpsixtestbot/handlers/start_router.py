import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from database.db import SessionLocal
from database.models import User
from utils.unique_id_generator import generate_unique_id
from states.registration import RegistrationStates
from states.test import TestStates
from keyboards.inline import start_inline_keyboard, question_keyboard
from utils.validators import validate_phone, validate_age
from utils.questions_loader import load_questions
from config import CHANNEL_IDS, BOT_TOKEN
from aiogram import Bot

start_router = Router()
bot = Bot(token=BOT_TOKEN)

# Logging sozlash
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_subscription(user_id: int) -> bool:
    """Foydalanuvchining barcha kanallarga obuna ekanligini tekshiradi."""
    try:
        for channel_id in CHANNEL_IDS:
            chat_member = await bot.get_chat_member(chat_id=channel_id, user_id=user_id)
            if chat_member.status not in ["member", "administrator", "creator"]:
                return False
        return True
    except Exception as e:
        logger.error(f"Error checking subscription for user {user_id}: {e}")
        return False

def get_subscription_keyboard():
    """Kanallar uchun inline tugmalar yaratadi."""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    keyboard = []
    for channel_id in CHANNEL_IDS:
        channel_name = channel_id.replace("@", "")
        keyboard.append([InlineKeyboardButton(
            text=f"{channel_id} | Obuna",
            url=f"https://t.me/{channel_name}"
        )])
    keyboard.append([InlineKeyboardButton(text="Tekshirish ✅", callback_data="check_subscription")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

@start_router.message(Command("start"))
async def start_command(message: Message, state: FSMContext):
    # Kanallarga obuna tekshiriladi
    if await check_subscription(message.from_user.id):
        await message.answer(
            "Xush kelibsiz! 😊 Psixologik testimizga qo‘shiling! Testni boshlash uchun tugmani bosing! 👇",
            reply_markup=start_inline_keyboard()
        )
        await state.set_state(None)
    else:
        await message.answer(
            "😊 Testni boshlash uchun quyidagi kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        await state.set_state(None)

@start_router.callback_query(F.data == "check_subscription")
async def check_subscription_callback(callback: CallbackQuery, state: FSMContext):
    if await check_subscription(callback.from_user.id):
        await callback.message.edit_text(
            "Xush kelibsiz! 😊 Psixologik testimizga qo‘shiling! Testni boshlash uchun tugmani bosing! 👇",
            reply_markup=start_inline_keyboard()
        )
    else:
        await callback.message.edit_text(
            "😔 Avval quyidagi kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
    await callback.answer()

@start_router.callback_query(F.data == "start_test")
async def start_registration(callback: CallbackQuery, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(callback.from_user.id):
        await callback.message.edit_text(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        await callback.answer()
        return

    logger.info(f"Starting registration for user {callback.from_user.id}")
    unique_id = generate_unique_id()
    try:
        with SessionLocal() as session:
            new_user = User(telegram_id=callback.from_user.id, unique_id=unique_id, status='new')
            session.add(new_user)
            session.commit()
            logger.info(f"New user created with unique_id {unique_id}")
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        await callback.message.answer("😔 Xato yuz berdi. Qayta urining.")
        await callback.answer()
        return

    await state.update_data(unique_id=unique_id)
    await callback.message.edit_text(f"Sizning ID: {unique_id}\nIsmingizni kiriting 😊")
    await state.set_state(RegistrationStates.first_name)
    await callback.answer()

@start_router.message(RegistrationStates.first_name)
async def process_first_name(message: Message, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(message.from_user.id):
        await message.answer(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        return

    data = await state.get_data()
    unique_id = data['unique_id']
    try:
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            user.first_name = message.text
            session.commit()
    except Exception as e:
        logger.error(f"Error in process_first_name: {e}")
        await message.answer("😔 Xato yuz berdi. Qayta urining.")
        return

    await message.answer("Familiyangizni kiriting 😊")
    await state.set_state(RegistrationStates.last_name)

@start_router.message(RegistrationStates.last_name)
async def process_last_name(message: Message, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(message.from_user.id):
        await message.answer(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        return

    data = await state.get_data()
    unique_id = data['unique_id']
    try:
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            user.last_name = message.text
            session.commit()
    except Exception as e:
        logger.error(f"Error in process_last_name: {e}")
        await message.answer("😔 Xato yuz berdi. Qayta urining.")
        return

    await message.answer("Telefon raqamingizni kiriting!  (Namuna: +998901234567) 📞")
    await state.set_state(RegistrationStates.phone_number)

@start_router.message(RegistrationStates.phone_number)
async def process_phone(message: Message, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(message.from_user.id):
        await message.answer(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        return

    if not validate_phone(message.text):
        await message.answer("Iltimos, telefon raqamingizni to‘g‘ri kiriting! Namuna: (+998901234567) 📞")
        return

    data = await state.get_data()
    unique_id = data['unique_id']
    try:
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            user.phone_number = message.text
            session.commit()
    except Exception as e:
        logger.error(f"Error in process_phone: {e}")
        await message.answer("😔 Xato yuz berdi. Qayta urining.")
        return

    await message.answer("Yoshingizni kiriting (raqam bilan, masalan, 25) 🎂")
    await state.set_state(RegistrationStates.age)

@start_router.message(RegistrationStates.age)
async def process_age(message: Message, state: FSMContext):
    # Obuna tekshiriladi
    if not await check_subscription(message.from_user.id):
        await message.answer(
            "😔 Avval kanallarga obuna bo‘ling:",
            reply_markup=get_subscription_keyboard()
        )
        return

    if not validate_age(message.text):
        await message.answer("Iltimos, yoshingizni to‘g‘ri raqam bilan kiriting (2-100) 🎂")
        return

    data = await state.get_data()
    unique_id = data['unique_id']
    try:
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            user.age = int(message.text)
            user.status = 'registered'
            first_name = user.first_name
            last_name = user.last_name
            phone_number = user.phone_number
            age = user.age
            session.commit()
            logger.info(f"User {unique_id} registered successfully")
    except Exception as e:
        logger.error(f"Error in process_age: {e}")
        await message.answer("😔 Xato yuz berdi. Qayta urining.")
        return

    # Ma'lumotlar tartibli ko'rsatiladi
    await message.answer(
        f"🎉 Ro‘yxatdan o‘tdingiz!\n"
        f"Ism: {first_name}\n"
        f"Familiya: {last_name}\n"
        f"Telefon: {phone_number}\n"
        f"Yosh: {age}"
    )

    # Test darhol yangi xabar sifatida boshlanadi
    try:
        with SessionLocal() as session:
            user = session.query(User).filter(User.unique_id == unique_id).first()
            user.status = 'test_started'
            session.commit()

        await state.update_data(unique_id=unique_id, current_question=1)
        questions = load_questions()
        q = questions[0]
        await message.answer(
            f"🌟 Savol 1/30: \n\n {q['question']}\n\n1: {q['options'][0]}\n2: {q['options'][1]}\n\nTanlang 😊",
            reply_markup=question_keyboard()
        )
        await state.set_state(TestStates.answering)
    except Exception as e:
        logger.error(f"Error starting test: {e}")
        await message.answer("😔 Testni boshlashda xato yuz berdi. /start bilan qayta urining.")
        await state.clear()