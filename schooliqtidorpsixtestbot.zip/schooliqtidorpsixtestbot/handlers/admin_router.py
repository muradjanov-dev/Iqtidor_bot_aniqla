import logging
from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database.db import SessionLocal
from database.models import User
from config import ADMIN_ID, BOT_TOKEN
from aiogram import Bot

admin_router = Router()
bot = Bot(token=BOT_TOKEN)

# Logging sozlash
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AdminStates(StatesGroup):
    reklama = State()

@admin_router.message(Command("reklama"))
async def start_reklama(message: Message, state: FSMContext):
    # ADMIN_ID ro'yxat sifatida qabul qilinadi
    admin_ids = [str(aid) for aid in (ADMIN_ID if isinstance(ADMIN_ID, list) else [ADMIN_ID])]
    logger.info(f"Checking admin: User ID = {message.from_user.id}, ADMIN_IDs = {admin_ids}")

    if str(message.from_user.id) not in admin_ids:
        await message.answer("😔 Bu buyruq faqat adminlar uchun!")
        logger.warning(f"User {message.from_user.id} tried to access /reklama but is not an admin")
        return

    await message.answer("📢 Reklama uchun matn, rasm, fayl yoki ovozli xabar yuboring (bir yoki bir nechtasini):")
    await state.set_state(AdminStates.reklama)

@admin_router.message(AdminStates.reklama)
async def send_reklama(message: Message, state: FSMContext):
    text = message.text or message.caption or ""
    photo = message.photo[-1] if message.photo else None
    document = message.document if message.document else None
    voice = message.voice if message.voice else None

    # Hech qanday kontent yuborilmagan bo'lsa
    if not text and not photo and not document and not voice:
        await message.answer("😔 Iltimos, reklama uchun matn, rasm, fayl yoki ovozli xabar yuboring.")
        return

    try:
        with SessionLocal() as session:
            users = session.query(User.telegram_id).distinct().all()
            user_ids = [user.telegram_id for user in users]
    except Exception as e:
        logger.error(f"Error fetching users: {e}")
        await message.answer("😔 Foydalanuvchilarni olishda xato yuz berdi.")
        await state.clear()
        return

    sent_count = 0
    for user_id in user_ids:
        try:
            if photo:
                await bot.send_photo(
                    chat_id=user_id,
                    photo=photo.file_id,
                    caption=text if text else None
                )
            elif document:
                await bot.send_document(
                    chat_id=user_id,
                    document=document.file_id,
                    caption=text if text else None
                )
            elif voice:
                await bot.send_voice(
                    chat_id=user_id,
                    voice=voice.file_id,
                    caption=text if text else None
                )
            else:
                await bot.send_message(
                    chat_id=user_id,
                    text=text
                )
            sent_count += 1
        except Exception as e:
            logger.error(f"Error sending reklama to user {user_id}: {e}")

    await message.answer(f"🎉 Reklama {sent_count} foydalanuvchiga muvaffaqiyatli yuborildi!")
    await state.clear()