CHANNELS = [
    {"name": "Afzalbek Mahmudov | Blog", "id": "@mahmudov_blog", "link": "https://t.me/mahmudov_blog"},
]

